import SpectreFinite.ParentOwnershipFinitePart000
import SpectreFinite.ParentOwnershipFinitePart001
import SpectreFinite.ParentOwnershipFinitePart002
import SpectreFinite.ParentOwnershipFinitePart003
import SpectreFinite.ParentOwnershipFinitePart004
import SpectreFinite.ParentOwnershipFinitePart005
import SpectreFinite.ParentOwnershipFinitePart006
import SpectreFinite.ParentOwnershipFinitePart007
import SpectreFinite.ParentOwnershipFinitePart008
import SpectreFinite.ParentOwnershipFinitePart009
import SpectreFinite.ParentOwnershipFinitePart010
import SpectreFinite.ParentOwnershipFinitePart011
import SpectreFinite.ParentOwnershipFinitePart012
import SpectreFinite.ParentOwnershipFinitePart013
import SpectreFinite.ParentOwnershipFinitePart014
import SpectreFinite.ParentOwnershipFinitePart015
import SpectreFinite.ParentOwnershipFinitePart016
import SpectreFinite.ParentOwnershipFinitePart017
import SpectreFinite.ParentOwnershipFinitePart018
import SpectreFinite.ParentOwnershipFinitePart019
import SpectreFinite.ParentOwnershipFinitePart020
import SpectreFinite.ParentOwnershipFinitePart021
import SpectreFinite.ParentOwnershipFinitePart022
import SpectreFinite.ParentOwnershipFinitePart023
import SpectreFinite.ParentOwnershipFinitePart024
import SpectreFinite.ParentOwnershipFinitePart025
import SpectreFinite.ParentOwnershipFinitePart026
import SpectreFinite.ParentOwnershipFinitePart027
import SpectreFinite.ParentOwnershipFinitePart028
import SpectreFinite.ParentOwnershipFinitePart029
import SpectreFinite.ParentOwnershipFinitePart030
import SpectreFinite.ParentOwnershipFinitePart031
import SpectreFinite.ParentOwnershipFinitePart032
import SpectreFinite.ParentOwnershipFinitePart033
import SpectreFinite.ParentOwnershipFinitePart034
import SpectreFinite.ParentOwnershipFinitePart035
import SpectreFinite.ParentOwnershipFinitePart036
import SpectreFinite.ParentOwnershipFinitePart037
import SpectreFinite.ParentOwnershipFinitePart038
import SpectreFinite.ParentOwnershipFinitePart039
import SpectreFinite.ParentOwnershipFinitePart040
import SpectreFinite.ParentOwnershipFinitePart041
import SpectreFinite.ParentOwnershipFinitePart042
import SpectreFinite.ParentOwnershipFinitePart043
import SpectreFinite.ParentOwnershipFinitePart044
import SpectreFinite.ParentOwnershipFinitePart045
import SpectreFinite.ParentOwnershipFinitePart046
import SpectreFinite.ParentOwnershipFinitePart047
import SpectreFinite.ParentOwnershipFinitePart048
import SpectreFinite.ParentOwnershipFinitePart049
import SpectreFinite.ParentOwnershipFinitePart050
import SpectreFinite.ParentOwnershipFinitePart051
import SpectreFinite.ParentOwnershipFinitePart052
import SpectreFinite.ParentOwnershipFinitePart053
import SpectreFinite.ParentOwnershipFinitePart054
import SpectreFinite.ParentOwnershipFinitePart055
import SpectreFinite.ParentOwnershipFinitePart056
import SpectreFinite.ParentOwnershipFinitePart057
import SpectreFinite.ParentOwnershipFinitePart058
import SpectreFinite.ParentOwnershipFinitePart059
import SpectreFinite.ParentOwnershipFinitePart060
import SpectreFinite.ParentOwnershipFinitePart061
import SpectreFinite.ParentOwnershipFinitePart062
import SpectreFinite.ParentOwnershipFinitePart063
import SpectreFinite.ParentOwnershipFinitePart064
import SpectreFinite.ParentOwnershipFinitePart065
import SpectreFinite.ParentOwnershipFinitePart066
import SpectreFinite.ParentOwnershipFinitePart067
import SpectreFinite.ParentOwnershipFinitePart068
import SpectreFinite.ParentOwnershipFinitePart069
import SpectreFinite.ParentOwnershipFinitePart070
import SpectreFinite.ParentOwnershipFinitePart071
import SpectreFinite.ParentOwnershipFinitePart072
import SpectreFinite.ParentOwnershipFinitePart073
import SpectreFinite.ParentOwnershipFinitePart074
import SpectreFinite.ParentOwnershipFinitePart075
import SpectreFinite.ParentOwnershipFinitePart076
import SpectreFinite.ParentOwnershipFinitePart077
import SpectreFinite.ParentOwnershipFinitePart078
import SpectreFinite.ParentOwnershipFinitePart079
import SpectreFinite.ParentOwnershipFinitePart080
import SpectreFinite.ParentOwnershipFinitePart081
import SpectreFinite.ParentOwnershipFinitePart082
import SpectreFinite.ParentOwnershipFinitePart083
import SpectreFinite.ParentOwnershipFinitePart084
import SpectreFinite.ParentOwnershipFinitePart085
import SpectreFinite.ParentOwnershipFinitePart086
import SpectreFinite.ParentOwnershipFinitePart087
import SpectreFinite.ParentOwnershipFinitePart088
import SpectreFinite.ParentOwnershipFinitePart089
import SpectreFinite.ParentOwnershipFinitePart090
import SpectreFinite.ParentOwnershipFinitePart091
import SpectreFinite.ParentOwnershipFinitePart092
import SpectreFinite.ParentOwnershipFinitePart093
import SpectreFinite.ParentOwnershipFinitePart094
import SpectreFinite.ParentOwnershipFinitePart095
import SpectreFinite.ParentOwnershipFinitePart096
import SpectreFinite.ParentOwnershipFinitePart097
import SpectreFinite.ParentOwnershipFinitePart098
import SpectreFinite.ParentOwnershipFinitePart099
import SpectreFinite.ParentOwnershipFinitePart100
import SpectreFinite.ParentOwnershipFinitePart101
import SpectreFinite.ParentOwnershipFinitePart102
import SpectreFinite.ParentOwnershipFinitePart103
import SpectreFinite.ParentOwnershipFinitePart104
import SpectreFinite.ParentOwnershipFinitePart105
import SpectreFinite.ParentOwnershipFinitePart106
import SpectreFinite.ParentOwnershipFinitePart107
import SpectreFinite.ParentOwnershipFinitePart108
import SpectreFinite.ParentOwnershipFinitePart109
import SpectreFinite.ParentOwnershipFinitePart110
import SpectreFinite.ParentOwnershipFinitePart111
import SpectreFinite.ParentOwnershipFinitePart112
import SpectreFinite.ParentOwnershipFinitePart113
import SpectreFinite.ParentOwnershipFinitePart114
import SpectreFinite.ParentOwnershipFinitePart115
import SpectreFinite.ParentOwnershipFinitePart116
import SpectreFinite.ParentOwnershipFinitePart117
import SpectreFinite.ParentOwnershipFinitePart118
import SpectreFinite.ParentOwnershipFinitePart119
import SpectreFinite.ParentOwnershipFinitePart120
import SpectreFinite.ParentOwnershipFinitePart121
import SpectreFinite.ParentOwnershipFinitePart122
import SpectreFinite.ParentOwnershipFinitePart123
import SpectreFinite.ParentOwnershipFinitePart124
import SpectreFinite.ParentOwnershipFinitePart125
import SpectreFinite.ParentOwnershipFinitePart126
import SpectreFinite.ParentOwnershipFinitePart127
import SpectreFinite.ParentOwnershipFinitePart128
import SpectreFinite.ParentOwnershipFinitePart129
import SpectreFinite.ParentOwnershipFinitePart130
import SpectreFinite.ParentOwnershipFinitePart131

/-! Literal finite certification of the 2112 regenerated radius-five rows.
This module has no theorem asserting that the rows exhaust occurring windows.
The final whole-field consequences retain OccurrenceComplete as a premise.
-/
namespace SpectreFinite.HexSearch.ParentOwnership

def certifiedParentChunks : List (List (List State)) := [parentRows000,parentRows001,parentRows002,parentRows003,parentRows004,parentRows005,parentRows006,parentRows007,parentRows008,parentRows009,parentRows010,parentRows011,parentRows012,parentRows013,parentRows014,parentRows015,parentRows016,parentRows017,parentRows018,parentRows019,parentRows020,parentRows021,parentRows022,parentRows023,parentRows024,parentRows025,parentRows026,parentRows027,parentRows028,parentRows029,parentRows030,parentRows031,parentRows032,parentRows033,parentRows034,parentRows035,parentRows036,parentRows037,parentRows038,parentRows039,parentRows040,parentRows041,parentRows042,parentRows043,parentRows044,parentRows045,parentRows046,parentRows047,parentRows048,parentRows049,parentRows050,parentRows051,parentRows052,parentRows053,parentRows054,parentRows055,parentRows056,parentRows057,parentRows058,parentRows059,parentRows060,parentRows061,parentRows062,parentRows063,parentRows064,parentRows065,parentRows066,parentRows067,parentRows068,parentRows069,parentRows070,parentRows071,parentRows072,parentRows073,parentRows074,parentRows075,parentRows076,parentRows077,parentRows078,parentRows079,parentRows080,parentRows081,parentRows082,parentRows083,parentRows084,parentRows085,parentRows086,parentRows087,parentRows088,parentRows089,parentRows090,parentRows091,parentRows092,parentRows093,parentRows094,parentRows095,parentRows096,parentRows097,parentRows098,parentRows099,parentRows100,parentRows101,parentRows102,parentRows103,parentRows104,parentRows105,parentRows106,parentRows107,parentRows108,parentRows109,parentRows110,parentRows111,parentRows112,parentRows113,parentRows114,parentRows115,parentRows116,parentRows117,parentRows118,parentRows119,parentRows120,parentRows121,parentRows122,parentRows123,parentRows124,parentRows125,parentRows126,parentRows127,parentRows128,parentRows129,parentRows130,parentRows131]
def certifiedParentRows : List (List State) := certifiedParentChunks.flatten
def certifiedParentFamily : List Patch := certifiedParentRows.map encodedPatch

theorem certifiedParentChunks_property : ∀ chunk ∈ certifiedParentChunks, ∀ row ∈ chunk, RowProperty row := by
  simp only [certifiedParentChunks, List.forall_mem_cons]
  exact ⟨parentRows000_property,⟨parentRows001_property,⟨parentRows002_property,⟨parentRows003_property,⟨parentRows004_property,⟨parentRows005_property,⟨parentRows006_property,⟨parentRows007_property,⟨parentRows008_property,⟨parentRows009_property,⟨parentRows010_property,⟨parentRows011_property,⟨parentRows012_property,⟨parentRows013_property,⟨parentRows014_property,⟨parentRows015_property,⟨parentRows016_property,⟨parentRows017_property,⟨parentRows018_property,⟨parentRows019_property,⟨parentRows020_property,⟨parentRows021_property,⟨parentRows022_property,⟨parentRows023_property,⟨parentRows024_property,⟨parentRows025_property,⟨parentRows026_property,⟨parentRows027_property,⟨parentRows028_property,⟨parentRows029_property,⟨parentRows030_property,⟨parentRows031_property,⟨parentRows032_property,⟨parentRows033_property,⟨parentRows034_property,⟨parentRows035_property,⟨parentRows036_property,⟨parentRows037_property,⟨parentRows038_property,⟨parentRows039_property,⟨parentRows040_property,⟨parentRows041_property,⟨parentRows042_property,⟨parentRows043_property,⟨parentRows044_property,⟨parentRows045_property,⟨parentRows046_property,⟨parentRows047_property,⟨parentRows048_property,⟨parentRows049_property,⟨parentRows050_property,⟨parentRows051_property,⟨parentRows052_property,⟨parentRows053_property,⟨parentRows054_property,⟨parentRows055_property,⟨parentRows056_property,⟨parentRows057_property,⟨parentRows058_property,⟨parentRows059_property,⟨parentRows060_property,⟨parentRows061_property,⟨parentRows062_property,⟨parentRows063_property,⟨parentRows064_property,⟨parentRows065_property,⟨parentRows066_property,⟨parentRows067_property,⟨parentRows068_property,⟨parentRows069_property,⟨parentRows070_property,⟨parentRows071_property,⟨parentRows072_property,⟨parentRows073_property,⟨parentRows074_property,⟨parentRows075_property,⟨parentRows076_property,⟨parentRows077_property,⟨parentRows078_property,⟨parentRows079_property,⟨parentRows080_property,⟨parentRows081_property,⟨parentRows082_property,⟨parentRows083_property,⟨parentRows084_property,⟨parentRows085_property,⟨parentRows086_property,⟨parentRows087_property,⟨parentRows088_property,⟨parentRows089_property,⟨parentRows090_property,⟨parentRows091_property,⟨parentRows092_property,⟨parentRows093_property,⟨parentRows094_property,⟨parentRows095_property,⟨parentRows096_property,⟨parentRows097_property,⟨parentRows098_property,⟨parentRows099_property,⟨parentRows100_property,⟨parentRows101_property,⟨parentRows102_property,⟨parentRows103_property,⟨parentRows104_property,⟨parentRows105_property,⟨parentRows106_property,⟨parentRows107_property,⟨parentRows108_property,⟨parentRows109_property,⟨parentRows110_property,⟨parentRows111_property,⟨parentRows112_property,⟨parentRows113_property,⟨parentRows114_property,⟨parentRows115_property,⟨parentRows116_property,⟨parentRows117_property,⟨parentRows118_property,⟨parentRows119_property,⟨parentRows120_property,⟨parentRows121_property,⟨parentRows122_property,⟨parentRows123_property,⟨parentRows124_property,⟨parentRows125_property,⟨parentRows126_property,⟨parentRows127_property,⟨parentRows128_property,⟨parentRows129_property,⟨parentRows130_property,⟨parentRows131_property,by simp⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩

theorem certifiedParentRows_property : ∀ row ∈ certifiedParentRows, RowProperty row := by
  intro row hr
  obtain ⟨chunk,hc,hr⟩ := List.mem_flatten.mp hr
  exact certifiedParentChunks_property chunk hc row hr

theorem certifiedParentRows_count : certifiedParentRows.length = 2112 := by
  rw [certifiedParentRows, List.length_flatten]
  change (List.replicate 132 (16 : Nat)).sum = 2112
  rw [List.sum_replicate_nat]

theorem certifiedParentFamily_count : certifiedParentFamily.length = 2112 := by
  rw [certifiedParentFamily,List.length_map,certifiedParentRows_count]

theorem certifiedParentFamily_unique : ∀ p ∈ certifiedParentFamily,
    UniqueAt (patchState p) (0,0) := by
  intro p hp
  obtain ⟨row,hr,rfl⟩ := List.mem_map.mp hp
  exact rowProperty_unique row (certifiedParentRows_property row hr)

theorem certifiedParentFamily_shape : ∀ p ∈ certifiedParentFamily,
    patchState p (0,0) = (0,0) → ListedRootParent (patchState p) := by
  intro p hp
  obtain ⟨row,hr,rfl⟩ := List.mem_map.mp hp
  exact rowProperty_shape row (certifiedParentRows_property row hr)

/-- Conditional only: the missing occurrence theorem is visible in the type. -/
theorem unique_ownership_of_certifiedParentFamily (f : Position → State)
    (hocc : OccurrenceComplete f (hexRegion 5) certifiedParentFamily) :
    ∀ x : Position, UniqueAt f x :=
  unique_ownership_of_radiusFive_certificate certifiedParentFamily
    certifiedParentFamily_unique f hocc

/-- Conditional complete parent pattern for every turn-zero Gamma anchor. -/
theorem listed_parent_of_certifiedParentFamily (f : Position → State)
    (hocc : OccurrenceComplete f (hexRegion 5) certifiedParentFamily)
    (center : Position) (hroot : f center = (0,0)) :
    ListedRootParent (shiftedField f center) :=
  listed_parent_of_radiusFive_certificate certifiedParentFamily
    certifiedParentFamily_shape f hocc center hroot

#print axioms certifiedParentFamily_unique
#print axioms certifiedParentFamily_shape
#print axioms unique_ownership_of_certifiedParentFamily
#print axioms listed_parent_of_certifiedParentFamily
end SpectreFinite.HexSearch.ParentOwnership
