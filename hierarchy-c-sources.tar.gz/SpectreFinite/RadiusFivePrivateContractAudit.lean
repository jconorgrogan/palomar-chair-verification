import SpectreFinite.RadiusFiveCertified
open SpectreFinite.HexSearch
#check RadiusFive.allTurnFamily_occurrenceComplete
#check RadiusFive.extract_mem_allTurnFamily
#check RadiusFive.familyForKind_counts
#check RadiusFive.allTurnFamily_count
example (f : Position → State) (hf : GloballyLegal f) : OccurrenceComplete f (hexRegion 5) RadiusFive.allTurnFamily := RadiusFive.allTurnFamily_occurrenceComplete f hf
#print axioms RadiusFive.allTurnFamily_occurrenceComplete
#print axioms RadiusFive.extract_mem_allTurnFamily
#print axioms RadiusFive.allTurnFamily_count
