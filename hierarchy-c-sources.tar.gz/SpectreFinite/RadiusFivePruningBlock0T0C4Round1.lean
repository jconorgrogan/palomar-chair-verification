import SpectreFinite.RadiusFivePruningBlock0T0C4Data
import SpectreFinite.RadiusFivePruningTrees
namespace SpectreFinite.HexSearch.RadiusFivePruning
open LargerWindowPruning
open SignaturePruning (KeyTree)
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
theorem check1_0_0_4 : checkRows direction samples1 trees1 rows1_0_0_4 = true := by
  rw [rows1_0_0_4, checkRows_materialize literalDomain direction samples1 leftIndices1 rightIndices1 leftSignature_index1 rightSignature_index1 trees1 indexedRows1_0_0_4]
  decide

end SpectreFinite.HexSearch.RadiusFivePruning
