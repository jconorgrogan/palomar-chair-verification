import SpectreFinite.RadiusFivePruningBlock0T0C4Data
import SpectreFinite.RadiusFivePruningTrees
namespace SpectreFinite.HexSearch.RadiusFivePruning
open LargerWindowPruning
open SignaturePruning (KeyTree)
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
theorem check4_0_0_4 : checkRows direction samples4 trees4 rows4_0_0_4 = true := by
  rw [rows4_0_0_4, checkRows_materialize literalDomain direction samples4 leftIndices4 rightIndices4 leftSignature_index4 rightSignature_index4 trees4 indexedRows4_0_0_4]
  decide

end SpectreFinite.HexSearch.RadiusFivePruning
