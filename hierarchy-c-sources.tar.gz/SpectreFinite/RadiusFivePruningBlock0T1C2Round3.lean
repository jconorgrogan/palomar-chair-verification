import SpectreFinite.RadiusFivePruningBlock0T1C2Data
import SpectreFinite.RadiusFivePruningTrees
namespace SpectreFinite.HexSearch.RadiusFivePruning
open LargerWindowPruning
open SignaturePruning (KeyTree)
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
theorem check3_0_1_2 : checkRows direction samples3 trees3 rows3_0_1_2 = true := by
  rw [rows3_0_1_2, checkRows_materialize literalDomain direction samples3 leftIndices3 rightIndices3 leftSignature_index3 rightSignature_index3 trees3 indexedRows3_0_1_2]
  decide

end SpectreFinite.HexSearch.RadiusFivePruning
