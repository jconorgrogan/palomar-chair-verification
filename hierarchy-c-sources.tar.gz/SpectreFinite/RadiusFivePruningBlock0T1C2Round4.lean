import SpectreFinite.RadiusFivePruningBlock0T1C2Data
import SpectreFinite.RadiusFivePruningTrees
namespace SpectreFinite.HexSearch.RadiusFivePruning
open LargerWindowPruning
open SignaturePruning (KeyTree)
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
theorem check4_0_1_2 : checkRows direction samples4 trees4 rows4_0_1_2 = true := by
  rw [rows4_0_1_2, checkRows_materialize literalDomain direction samples4 leftIndices4 rightIndices4 leftSignature_index4 rightSignature_index4 trees4 indexedRows4_0_1_2]
  decide

end SpectreFinite.HexSearch.RadiusFivePruning
