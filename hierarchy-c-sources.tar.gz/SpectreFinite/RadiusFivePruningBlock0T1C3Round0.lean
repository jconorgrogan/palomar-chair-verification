import SpectreFinite.RadiusFivePruningBlock0T1C3Data
import SpectreFinite.RadiusFivePruningTrees
namespace SpectreFinite.HexSearch.RadiusFivePruning
open LargerWindowPruning
open SignaturePruning (KeyTree)
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
theorem check0_0_1_3 : checkRows direction samples0 trees0 rows0_0_1_3 = true := by
  rw [rows0_0_1_3, checkRows_materialize literalDomain direction samples0 leftIndices0 rightIndices0 leftSignature_index0 rightSignature_index0 trees0 indexedRows0_0_1_3]
  decide

end SpectreFinite.HexSearch.RadiusFivePruning
