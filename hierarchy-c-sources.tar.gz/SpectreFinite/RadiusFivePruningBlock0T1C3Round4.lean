import SpectreFinite.RadiusFivePruningBlock0T1C3Data
import SpectreFinite.RadiusFivePruningTrees
namespace SpectreFinite.HexSearch.RadiusFivePruning
open LargerWindowPruning
open SignaturePruning (KeyTree)
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
theorem check4_0_1_3 : checkRows direction samples4 trees4 rows4_0_1_3 = true := by
  rw [rows4_0_1_3, checkRows_materialize literalDomain direction samples4 leftIndices4 rightIndices4 leftSignature_index4 rightSignature_index4 trees4 indexedRows4_0_1_3]
  decide

end SpectreFinite.HexSearch.RadiusFivePruning
