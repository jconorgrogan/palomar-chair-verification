# License and attribution notice

The manuscript and its supplied Markdown, DOCX and PDF editions retain the project's **Creative Commons Attribution 4.0 International (CC BY 4.0)** license. Author: **Conor Grogan**. The manuscript includes the applicable attribution to prior work and disclosure of AI contributions; those notices should be retained.

- License summary: https://creativecommons.org/licenses/by/4.0/
- Full license terms: https://creativecommons.org/licenses/by/4.0/legalcode.en

The document-generation scripts in this archive use **Apache License 2.0**, consistently with the project's code license. The full license is included in `licenses/Apache-2.0.txt`. The retained project license text is available at:

https://github.com/jconorgrogan/palomar-chair-verification/blob/9008dec3afc006a62d3d2fd6b49b12f189248f33/LICENSE

Python, python-docx, LibreOffice, DejaVu fonts, Lean, Mathlib and other dependencies retain their own licenses and notices. They are not included in this archive. No license or notice for a third-party work is changed by this package.
