# Aperiodic Monotiles in Every Dimension

**Conor Grogan**  
**22 October 2026 revision**  
*Finite full symmetry in every dimension above two*

This archive contains the complete dated manuscript and the files needed to reproduce its editable DOCX and PDF presentation. The Markdown is the canonical editable manuscript source. The supplied DOCX and PDF are the reviewed rendering of that source.

## Contents

- `revised/aperiodic-monotiles-every-dimension-2026-10-22.md`: manuscript source.
- `revised/aperiodic-monotiles-every-dimension-2026-10-22.docx`: editable Word document.
- `revised/aperiodic-monotiles-every-dimension-2026-10-22.pdf`: 15-page manuscript with source links.
- `render_manuscript.py`: Markdown-to-DOCX generator.
- `build_manuscript.sh`: DOCX and PDF build entry point.
- `LICENSE.md`: license scope and attribution notice.
- `licenses/Apache-2.0.txt`: Apache License 2.0 text retained from the project.
- `SHA256SUMS`: checksums for all other files in this archive.

No external graphics assets are required. Fonts and rendering software are dependencies, not bundled assets.

## Reproduce the document

Install Python 3, python-docx, LibreOffice and the DejaVu Serif, DejaVu Sans and DejaVu Sans Mono fonts. Ensure `python3` and `soffice` are available on the command line. Then, from this archive's root, run:

```sh
bash build_manuscript.sh
```

Fresh files are written to `build/`; the supplied manuscript files remain unchanged. An optional first argument selects another output directory. For DOCX only:

```sh
python3 render_manuscript.py --output build/aperiodic-monotiles-every-dimension-2026-10-22.docx
```

The supplied documents were generated using python-docx 1.2.0 and LibreOfficeDev 26.8.0.0.alpha0, build `2c87e51eeaa2b413ff4ae097b2705eea1995d8e5`. Font and renderer versions may change pagination, and timestamps or document metadata may change binary hashes. The source, supplied documents and scripts are individually identified by `SHA256SUMS`.

## Mathematical and verification scope

The manuscript covers every integer dimension at least two, including the separate four-dimensional JACKIE construction. Its selected all-dimensional translation-aperiodicity endpoint compiled, but its final independent comparison, external-kernel checks, endpoint axiom audit and all-dimensional Palomar registration remain incomplete.

The stronger finite-full-symmetry result for dimensions greater than two is an ordinary mathematical deduction from the cited source lemmas, not a newly compiled or registered Lean endpoint. The numerical bound `2^d d!` is stated for dimension three and dimensions at least five, not for JACKIE. The manuscript records the exact status and limitations. Rebuilding the documents does not run or verify any Lean proof.

## Source and archival history

The project repository is [jconorgrogan/palomar-chair-verification](https://github.com/jconorgrogan/palomar-chair-verification). The manuscript cites immutable source commits, verification records, prior work and the retained historical manuscripts. This archive is a dated manuscript revision; it does not assign a new Zenodo DOI.

The earlier odd-prime companion paper remains identified by DOI [10.5281/zenodo.23197680](https://doi.org/10.5281/zenodo.23197680). That historical DOI is not a DOI for this all-dimensional revision. The version-family concept DOI is [10.5281/zenodo.23197474](https://doi.org/10.5281/zenodo.23197474).

Authorship, prior-work attribution, AI-contribution disclosure and verification limitations are retained in the manuscript. See `LICENSE.md` for the manuscript/code license distinction.
