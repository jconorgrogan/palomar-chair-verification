#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0
set -euo pipefail
root="$(cd "$(dirname "$0")" && pwd)"
out="${1:-$root/build}"
mkdir -p "$out"
out="$(cd "$out" && pwd)"
stem="aperiodic-monotiles-every-dimension-2026-10-22"
python3 "$root/render_manuscript.py" --input "$root/revised/$stem.md" --output "$out/$stem.docx"
profile="$(mktemp -d)"
trap 'rm -rf "$profile"' EXIT
soffice --headless "-env:UserInstallation=file://$profile" --convert-to pdf --outdir "$out" "$out/$stem.docx"
printf 'Generated DOCX and PDF in %s\n' "$out"
