# SPDX-License-Identifier: Apache-2.0
"""Render the dated Markdown manuscript to editable DOCX."""
from pathlib import Path
import argparse
import re
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.style import WD_STYLE_TYPE
from docx.opc.constants import RELATIONSHIP_TYPE as RT
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--input', type=Path, default=Path(__file__).resolve().parent / 'revised' / 'aperiodic-monotiles-every-dimension-2026-10-22.md')
parser.add_argument('--output', type=Path)
args = parser.parse_args()
md = args.input

doc=Document()
sec=doc.sections[0]
sec.page_width=Inches(8.5); sec.page_height=Inches(11)
sec.top_margin=Inches(.7); sec.bottom_margin=Inches(.65)
sec.left_margin=Inches(.8); sec.right_margin=Inches(.8)
sec.footer_distance=Inches(.3)
styles=doc.styles
for border in list(styles.element.iter(qn('w:pBdr'))):
 border.getparent().remove(border)
for name in ['Normal','Body Text','List Paragraph']:
 st=styles[name]; st.font.name='DejaVu Serif'; st.font.size=Pt(10.5)
 st.paragraph_format.space_after=Pt(5)
 st.paragraph_format.line_spacing=1.08
 st.paragraph_format.widow_control=True
for name,size in [('Title',23),('Subtitle',12),('Heading 1',14),('Heading 2',11.5),('Heading 3',11)]:
 st=styles[name]; st.font.name='DejaVu Sans'; st.font.size=Pt(size); st.font.color.rgb=RGBColor(0,0,0)
 st.font.bold=name!='Subtitle'
 st.paragraph_format.space_before=Pt(11 if name.startswith('Heading') else 0)
 st.paragraph_format.space_after=Pt(6)
 st.paragraph_format.keep_with_next=True
if 'Source Text' not in styles:
 st=styles.add_style('Source Text',WD_STYLE_TYPE.PARAGRAPH)
 st.font.name='DejaVu Sans Mono'; st.font.size=Pt(8.1)
 st.paragraph_format.space_after=Pt(6); st.paragraph_format.space_before=Pt(3)
 st.paragraph_format.line_spacing=1.0; st.paragraph_format.keep_together=True
 st.paragraph_format.left_indent=Inches(.14)
 st.paragraph_format.right_indent=Inches(.06)
 st=styles['Source Text']
footer=sec.footer.paragraphs[0]
footer.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=footer.add_run(); r.font.name='DejaVu Sans'; r.font.size=Pt(8)
f=OxmlElement('w:fldSimple'); f.set(qn('w:instr'),'PAGE'); r._r.addnext(f)

def hyperlink(p,text,url):
 h=OxmlElement('w:hyperlink'); h.set(qn('r:id'),p.part.relate_to(url,RT.HYPERLINK,is_external=True))
 r=OxmlElement('w:r'); prop=OxmlElement('w:rPr'); co=OxmlElement('w:color');co.set(qn('w:val'),'174E7A');prop.append(co)
 r.append(prop); t=OxmlElement('w:t');t.text=text;r.append(t);h.append(r);p._p.append(h)

def inline(p,s):
 # The manuscript has only ordinary text and standard Markdown links.
 pos=0
 for m in re.finditer(r'\[([^\]]+)\]\(([^)]+)\)',s):
  if m.start()>pos:p.add_run(s[pos:m.start()])
  hyperlink(p,m.group(1),m.group(2));pos=m.end()
 if pos<len(s):p.add_run(s[pos:])
lines=md.read_text().splitlines();i=0; body_started=False
while i<len(lines):
 line=lines[i]
 if not line.strip():i+=1;continue
 if line.startswith('```'):
  code=[];i+=1
  while i<len(lines) and not lines[i].startswith('```'):
   code.append(lines[i]);i+=1
  p=doc.add_paragraph(style='Source Text');p.add_run('\n'.join(code));i+=1;continue
 if line.startswith('# '):
  p=doc.add_paragraph(line[2:],'Title');i+=1;continue
 if line.startswith('## '):
  p=doc.add_paragraph(line[3:],'Heading 1');i+=1;body_started=True;continue
 if line.startswith('### '):
  p=doc.add_paragraph(line[4:],'Heading 2');i+=1;body_started=True;continue
 if not body_started:
  p=doc.add_paragraph(line,'Subtitle' if line.startswith('Finite full') else 'Normal')
  if line=='Conor Grogan':p.runs[0].bold=True
  i+=1;continue
 # Each nonblank manuscript line is one paragraph; no reflow of source snippets.
 p=doc.add_paragraph()
 if line.startswith('- '):
  p.paragraph_format.left_indent=Inches(.17)
  p.paragraph_format.first_line_indent=Inches(-.17)
  inline(p,'• '+line[2:])
 elif re.match(r'^\d+\. ',line):
  p.paragraph_format.left_indent=Inches(.18)
  p.paragraph_format.first_line_indent=Inches(-.18)
  inline(p,line)
 else:inline(p,line)
 i+=1
props=doc.core_properties
props.title='Aperiodic Monotiles in Every Dimension'
props.subject='Finite full symmetry in every dimension above two'
props.author='Conor Grogan'
props.keywords='aperiodic monotile, JACKIE, CLARK, Lean, finite symmetry'
props.comments='22 October 2026 revision of the all-dimensional working manuscript.'
output=args.output or md.with_suffix('.docx')
output.parent.mkdir(parents=True, exist_ok=True)
doc.save(output)
print(output)
