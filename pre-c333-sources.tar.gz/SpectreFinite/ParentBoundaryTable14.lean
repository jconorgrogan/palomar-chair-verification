module

public import SpectreFinite.ParentBoundaryTransfer

@[expose] public section


/-! Untrusted witness values, validated below by ordinary kernel reduction. -/
namespace SpectreFinite.HexSearch.ParentBoundary
open ParentOwnership Boundary

def boundaryTable14 : OwnerTable := [((0,2),((-2),2)),(((-1),2),((-2),2)),(((-1),1),((-2),2)),(((-1),0),((-2),0)),(((-1),(-1)),(1,(-3))),((0,(-2)),(1,(-3))),((1,(-2)),(1,(-3))),((2,(-3)),(4,(-4))),((3,(-3)),(4,(-4))),((3,(-2)),(4,(-4))),((3,(-1)),(4,0)),((2,0),(4,0)),((2,1),(1,2)),((1,2),(1,2)),((1,1),(0,0)),((0,1),(0,0)),((0,0),(0,0)),((0,(-1)),(0,0)),((1,(-1)),(0,0)),((2,(-2)),(0,0)),((2,(-1)),(0,0)),((1,0),(0,0))]
def boundaryNeighbors14 : List Position := [((-2),2),((-2),0),(1,(-3)),(4,(-4)),(4,0),(1,2)]

theorem boundaryTable14_covers : ∀ x ∈ support 7,
    tableOwners boundaryTable14 x ≠ [] := by
  rw [support_exact]
  decide

theorem boundaryTable14_structure :
    Structure (tableOwners boundaryTable14) 7 boundaryNeighbors14 := by decide

#print axioms boundaryTable14_structure
end SpectreFinite.HexSearch.ParentBoundary
